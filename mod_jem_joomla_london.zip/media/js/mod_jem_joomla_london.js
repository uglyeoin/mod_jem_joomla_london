var height = document.getElementById('mod_koy_sticky_contact').offsetHeight;
document.body.style.paddingBottom = height+"px";